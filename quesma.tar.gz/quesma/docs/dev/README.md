Quesma development documentation
===============================

This folder contains loosely organized development documentation/notes, which - while being public on GitHub - are not intended for publishing to the main documentation site.